﻿using UnityEngine;
using System.Collections;

public class PlayerControls : MonoBehaviour {
	public int speed = 10;
	public int maxSpeed = 15;
	public int jumpForce = 10;
	public Transform target;
	public static Transform currCheckPoint;
	public Camera playerCam;
	public GUITexture guiCSpirit;
	public int dis2Player = -10;
	public int maxHealth = 100;
	public static int difficulty = 0;
	public string level2Load;
	public string curLevel;
	
	private int curHealth = 100;
	private bool onGround;
	private Vector3 velocity = Vector3.zero;
	private float smoothTime = 0.2f;
	private int count = 20;

	protected Animator santa;

	void Awake(){
		santa = GetComponentInChildren<Animator>();

		guiCSpirit.pixelInset = new Rect(Screen.width / 3, Screen.height / 3 * -1, 256, 128);
	}


	void OnCollisionStay2D(Collision2D col2d){

		if(col2d.collider.tag == "Ground"){
			onGround = true;
		}
	}

	void OnTriggerEnter2D(Collider2D col2d) {
		if(col2d.tag == "Health"){
			curHealth = curHealth + 50;
		}

		if(col2d.tag == "End"){
			curHealth = maxHealth;
			Application.LoadLevel(level2Load);
		}
	}

	void OnCollisionEnter2D(Collision2D col2d) {
		if(col2d.collider.tag == "Harmful"){
			Vector2 contactPoint = Vector2.zero;

			foreach (ContactPoint2D contact in col2d.contacts){
				contactPoint = contact.point;
				
			}
			Vector2 myTrans = transform.position;
			Vector2 dir = contactPoint - myTrans;
			rigidbody2D.AddForce(dir.normalized * jumpForce * -100 * Time.deltaTime);
			curHealth = curHealth - 50;
		}
	}

	void OnCollisionExit2D(Collision2D col2d) {
		if(col2d.collider.tag == "Ground"){
			onGround = false;
		}
	}

	void Update(){
		if(Input.GetButtonDown("Jump")){
			if(onGround){
				rigidbody2D.AddForce(Vector2.up * jumpForce * 100 * Time.deltaTime);
				onGround = false;
				santa.SetTrigger("Jump");
			}
		}
	}


	void FixedUpdate(){


		RaycastHit hit = new RaycastHit();

		if (Physics.Raycast(transform.position, -Vector3.up, out hit, 0.1f)){
			float distanceToGround = hit.distance;
			if(hit.collider.tag == "Ground") onGround = true;
			else onGround = false;
		}


		Vector2 vel = rigidbody2D.velocity;
		float h = Input.GetAxis("Horizontal");

		santa.SetFloat("Speed", h);

		Vector3 targetPosition = target.TransformPoint(new Vector3(0, 0, dis2Player));
		playerCam.transform.position = Vector3.SmoothDamp(playerCam.transform.position, targetPosition, ref velocity, smoothTime);

		if(curHealth >= maxHealth){
			curHealth = maxHealth;
		}

		if(curHealth == 50 && curHealth <= 50){
			guiCSpirit.gameObject.guiTexture.enabled = false;
			santa.SetBool("Bloodied", true);
		}
		else{
			guiCSpirit.gameObject.guiTexture.enabled = true;
			santa.SetBool("Bloodied", false);
		}

		if(curHealth <= difficulty){
			if(!MainMenu.yoloMode){
			Destroy(gameObject);
			Application.LoadLevel(curLevel);
			}
			else Application.LoadLevel("MainMenu");
		}

		if(onGround){
		float step = speed * h * Time.deltaTime;
			transform.Translate(Vector3.right * speed * h * Time.deltaTime);
		}

		if(!onGround){
			float step = speed * (h / 2) *  Time.deltaTime;
			transform.Translate(Vector3.right * speed * h * Time.deltaTime);
		}
		
		/* //Floaty Controls

		if(h * rigidbody2D.velocity.x < maxSpeed && !onGround){
			rigidbody2D.AddForce(Vector2.right * h * speed / 2);
		}
		
		if(Mathf.Abs(rigidbody2D.velocity.x) > maxSpeed && !onGround){
			rigidbody2D.velocity = new Vector2(Mathf.Sign(rigidbody2D.velocity.x) * maxSpeed, rigidbody2D.velocity.y);
		}

		////////////////////////////////////////

		if(h * rigidbody2D.velocity.x < maxSpeed && onGround){
			rigidbody2D.AddForce(Vector2.right * h * speed);
		}

		if(Mathf.Abs(rigidbody2D.velocity.x) > maxSpeed && onGround){
			rigidbody2D.velocity = new Vector2(Mathf.Sign(rigidbody2D.velocity.x) * maxSpeed, rigidbody2D.velocity.y);
		}
		*/


		if(Input.GetButtonDown("Down")){
			if(!onGround){
				rigidbody2D.AddForce(Vector2.up * jumpForce * -50 * Time.deltaTime);
			}
		}


	}
	
}
