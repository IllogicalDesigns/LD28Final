﻿using UnityEngine;
using System.Collections;

public class BossFight : MonoBehaviour {
	public Transform Player;
	public Transform target;
	public Transform Handtarget1;
	public Transform Handtarget2;
	public Transform Hand1;
	public Transform Hand2;

	private Vector3 velocity = Vector3.zero;
	private float smoothTime = 1;
	private float smoothTimeHands = 0.1f;
	private int dis2Player = 2;
	public bool onDamRun = false;

	// Update is called once per frame
	void FixedUpdate () {

		target.position = Player.position;
		
		Vector3 targetPosition = target.TransformPoint(new Vector3(0, 0, dis2Player));
		transform.position = Vector3.SmoothDamp(transform.position, targetPosition, ref velocity, smoothTime);

		if(!onDamRun){

			Hand1.position = Vector3.SmoothDamp(Hand1.position, Handtarget1.position, ref velocity, smoothTimeHands);
			Hand2.position = Vector3.SmoothDamp(Hand2.position, Handtarget2.position, ref velocity, smoothTimeHands);
		}
		else{
			bool first = false;
			if(first){
			Handtarget1.position = Player.position;
			Handtarget2.position = Player.position;
			first = false;
			}

			Hand1.position = Vector3.SmoothDamp(Hand1.position, Handtarget1.position, ref velocity, smoothTimeHands);
			Hand2.position = Vector3.SmoothDamp(Hand2.position, Handtarget2.position, ref velocity, smoothTimeHands);
		}

	}
}
