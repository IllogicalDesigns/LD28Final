﻿using UnityEngine;
using System.Collections;

public class SawScript : MonoBehaviour {
	public Transform sawPointA;
	public Transform sawPointB;
	public Transform sawObject;
	public Transform target;
	public int speed = 10;
	public int rotspeed = 10;
	public bool spinning = true;

	void Awake(){
		target.position = sawPointA.position;
	}

	// Update is called once per frame
	void Update () {
		//if at saw 1 got0 saw 2
		if(sawObject.position == sawPointA.position){
			target.position = sawPointB.position;
		}

		//if at saw 2 goto saw 1
		if(sawObject.position == sawPointB.position){
			target.position = sawPointA.position;
		}


		float step = speed * Time.deltaTime;
		sawObject.position = Vector3.MoveTowards(sawObject.position, target.position, step);

		if(spinning){
		sawObject.Rotate(Vector3.forward * rotspeed * Time.deltaTime);
		}

		Debug.DrawLine(sawPointA.position, sawPointB.position);
	
	}
}
