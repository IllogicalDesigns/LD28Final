﻿using UnityEngine;
using System.Collections;

public class MainMenu : MonoBehaviour {
	public Rigidbody playbutton;
	public GameObject playbutton1;
	public GameObject yolo;

	public static bool yoloMode = false;

	void OnTriggerEnter(Collider col) {
		if(col.collider.name == "PlayButton"){
			Application.LoadLevel("Level1");
		}
	}
	
	void Update () {

	Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
	RaycastHit hit;
	
	if(yoloMode){
			yolo.renderer.enabled = true;
		}
		else yolo.renderer.enabled = false;

	if (Physics.Raycast(ray, out hit, 100)){
		Debug.Log(hit.collider.name);
		Debug.DrawLine(ray.origin, hit.point);

			if(hit.collider.name == "You_Only_Get_One_Mode_0"){
				if(Input.GetMouseButtonDown(0)){
					yoloMode =! yoloMode;
				}
			}

			if(hit.collider.name == "PlayButton"){

				playbutton.renderer.enabled = false;
				playbutton1.renderer.enabled = true;

				if(Input.GetMouseButtonDown(0)){
					playbutton.renderer.enabled = true;
					playbutton1.renderer.enabled = false;
					playbutton.rigidbody.isKinematic = false;
					playbutton.rigidbody.AddForce(Vector3.up);
				}
			}
			else{
				playbutton.renderer.enabled = true;
				playbutton1.renderer.enabled = false;
			}

		}
	}

}
